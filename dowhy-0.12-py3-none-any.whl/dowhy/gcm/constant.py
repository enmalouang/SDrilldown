import numpy as np

# Smallest possible value. This is used in various algorithm for numerical stability.
EPS = np.finfo(np.float64).eps
