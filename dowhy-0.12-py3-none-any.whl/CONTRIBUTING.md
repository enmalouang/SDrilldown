
<!-- ALL-CONTRIBUTORS-BADGE:START - Do not remove or modify this section -->
[![All Contributors](https://img.shields.io/badge/all_contributors-42-orange.svg?style=flat-square)](#contributors-)
<!-- ALL-CONTRIBUTORS-BADGE:END -->

## Contributors ✨

Thanks goes to these wonderful people ([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tbody>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/emrekiciman"><img src="https://avatars3.githubusercontent.com/u/5982160?v=4?s=100" width="100px;" alt="emrekiciman"/><br /><sub><b>emrekiciman</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=emrekiciman" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/amit-sharma"><img src="https://avatars3.githubusercontent.com/u/1775381?v=4?s=100" width="100px;" alt="Amit Sharma"/><br /><sub><b>Amit Sharma</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=amit-sharma" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="http://adamkelleher.com"><img src="https://avatars0.githubusercontent.com/u/1762368?v=4?s=100" width="100px;" alt="Adam Kelleher"/><br /><sub><b>Adam Kelleher</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=akelleh" title="Code">💻</a> <a href="#content-akelleh" title="Content">🖋</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/Tanmay-Kulkarni101"><img src="https://avatars3.githubusercontent.com/u/17275495?v=4?s=100" width="100px;" alt="Tanmay Kulkarni"/><br /><sub><b>Tanmay Kulkarni</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=Tanmay-Kulkarni101" title="Code">💻</a> <a href="https://github.com/py-why/dowhy/commits?author=Tanmay-Kulkarni101" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/vojavocni"><img src="https://avatars.githubusercontent.com/u/40206443?v=4?s=100" width="100px;" alt="Aleksandar Jovanovic"/><br /><sub><b>Aleksandar Jovanovic</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=vojavocni" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/n8sty"><img src="https://avatars.githubusercontent.com/u/2964996?v=4?s=100" width="100px;" alt="nate giraldi"/><br /><sub><b>nate giraldi</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=n8sty" title="Documentation">📖</a> <a href="https://github.com/py-why/dowhy/commits?author=n8sty" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/yaakx"><img src="https://avatars.githubusercontent.com/u/54352800?v=4?s=100" width="100px;" alt="Julen Corral"/><br /><sub><b>Julen Corral</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=yaakx" title="Code">💻</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="http://toppare.github.io/"><img src="https://avatars.githubusercontent.com/u/6221127?v=4?s=100" width="100px;" alt="Baran Toppare"/><br /><sub><b>Baran Toppare</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=toppare" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/EgorKraevTransferwise"><img src="https://avatars.githubusercontent.com/u/62890791?v=4?s=100" width="100px;" alt="EgorKraevTransferwise"/><br /><sub><b>EgorKraevTransferwise</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=EgorKraevTransferwise" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/ryanrussell"><img src="https://avatars.githubusercontent.com/u/523300?v=4?s=100" width="100px;" alt="Ryan Russell"/><br /><sub><b>Ryan Russell</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=ryanrussell" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/MichaelMarien"><img src="https://avatars.githubusercontent.com/u/13829139?v=4?s=100" width="100px;" alt="MichaelMarien"/><br /><sub><b>MichaelMarien</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=MichaelMarien" title="Code">💻</a> <a href="https://github.com/py-why/dowhy/commits?author=MichaelMarien" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="14.28%"><a href="http://people.mpi-inf.mpg.de/~kbudhath/"><img src="https://avatars.githubusercontent.com/u/111277?v=4?s=100" width="100px;" alt="Kailashbuki"/><br /><sub><b>Kailashbuki</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=kailashbuki" title="Code">💻</a> <a href="https://github.com/py-why/dowhy/commits?author=kailashbuki" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/petergtz"><img src="https://avatars.githubusercontent.com/u/3618401?v=4?s=100" width="100px;" alt="Peter Götz"/><br /><sub><b>Peter Götz</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=petergtz" title="Code">💻</a> <a href="https://github.com/py-why/dowhy/commits?author=petergtz" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/bloebp"><img src="https://avatars.githubusercontent.com/u/51325689?v=4?s=100" width="100px;" alt="Patrick Blöbaum"/><br /><sub><b>Patrick Blöbaum</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=bloebp" title="Code">💻</a> <a href="https://github.com/py-why/dowhy/commits?author=bloebp" title="Documentation">📖</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/itsoum"><img src="https://avatars.githubusercontent.com/u/9675299?v=4?s=100" width="100px;" alt="Ilias Tsoumas"/><br /><sub><b>Ilias Tsoumas</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=itsoum" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/elikling"><img src="https://avatars.githubusercontent.com/u/8556526?v=4?s=100" width="100px;" alt="Eli Y. Kling"/><br /><sub><b>Eli Y. Kling</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=elikling" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="14.28%"><a href="http://astoeffelbauer.github.io"><img src="https://avatars.githubusercontent.com/u/54737457?v=4?s=100" width="100px;" alt="Andreas Stöffelbauer"/><br /><sub><b>Andreas Stöffelbauer</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=astoeffelbauer" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/esmucler"><img src="https://avatars.githubusercontent.com/u/14080095?v=4?s=100" width="100px;" alt="Ezequiel Smucler"/><br /><sub><b>Ezequiel Smucler</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=esmucler" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/yemaedahrav"><img src="https://avatars.githubusercontent.com/u/50958687?v=4?s=100" width="100px;" alt="Amey Varhade"/><br /><sub><b>Amey Varhade</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=yemaedahrav" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/bkowshik"><img src="https://avatars.githubusercontent.com/u/2899501?v=4?s=100" width="100px;" alt="Bhargav Kowshik"/><br /><sub><b>Bhargav Kowshik</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=bkowshik" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/darthtrevino"><img src="https://avatars.githubusercontent.com/u/113544?v=4?s=100" width="100px;" alt="Chris Trevino"/><br /><sub><b>Chris Trevino</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=darthtrevino" title="Code">💻</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://jlgleason.github.io"><img src="https://avatars.githubusercontent.com/u/18729651?v=4?s=100" width="100px;" alt="Jeffrey Gleason"/><br /><sub><b>Jeffrey Gleason</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=jlgleason" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://bandism.net/"><img src="https://avatars.githubusercontent.com/u/22633385?v=4?s=100" width="100px;" alt="Ikko Ashimine"/><br /><sub><b>Ikko Ashimine</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=eltociear" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="14.28%"><a href="http://eeulig.com"><img src="https://avatars.githubusercontent.com/u/87869465?v=4?s=100" width="100px;" alt="Elias"/><br /><sub><b>Elias</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=eeulig" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/Padarn"><img src="https://avatars.githubusercontent.com/u/858039?v=4?s=100" width="100px;" alt="Padarn Wilson"/><br /><sub><b>Padarn Wilson</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=Padarn" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="http://michaelkoberst.com"><img src="https://avatars.githubusercontent.com/u/15187387?v=4?s=100" width="100px;" alt="Michael Oberst"/><br /><sub><b>Michael Oberst</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=moberst" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="http://www.klesel.info"><img src="https://avatars.githubusercontent.com/u/41738984?v=4?s=100" width="100px;" alt="Michael Klesel"/><br /><sub><b>Michael Klesel</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=Klesel" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/MFreidank"><img src="https://avatars.githubusercontent.com/u/6368040?v=4?s=100" width="100px;" alt="Moritz Freidank"/><br /><sub><b>Moritz Freidank</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=MFreidank" title="Code">💻</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="http://stjohngrimbly.com"><img src="https://avatars.githubusercontent.com/u/28342957?v=4?s=100" width="100px;" alt="St John Grimbly"/><br /><sub><b>St John Grimbly</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=sgrimbly" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://lukasheumos.com"><img src="https://avatars.githubusercontent.com/u/21954664?v=4?s=100" width="100px;" alt="Lukas Heumos"/><br /><sub><b>Lukas Heumos</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=Zethson" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="http://www.logstotal.com"><img src="https://avatars.githubusercontent.com/u/315964?v=4?s=100" width="100px;" alt="Dr. Di Prodi"/><br /><sub><b>Dr. Di Prodi</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=robomotic" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://bhatt-priyadutt.github.io/priyadutt-portfolio/"><img src="https://avatars.githubusercontent.com/u/68959880?v=4?s=100" width="100px;" alt="Priyadutt"/><br /><sub><b>Priyadutt</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=bhatt-priyadutt" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/drawlinson"><img src="https://avatars.githubusercontent.com/u/1892448?v=4?s=100" width="100px;" alt="drawlinson"/><br /><sub><b>drawlinson</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=drawlinson" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/dw-610"><img src="https://avatars.githubusercontent.com/u/139509928?v=4?s=100" width="100px;" alt="Dylan W"/><br /><sub><b>Dylan W</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=dw-610" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/victor5as"><img src="https://avatars.githubusercontent.com/u/33633851?v=4?s=100" width="100px;" alt="Víctor Quintas-Martínez"/><br /><sub><b>Víctor Quintas-Martínez</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=victor5as" title="Code">💻</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://www.linkedin.com/in/rahulbshrestha/"><img src="https://avatars.githubusercontent.com/u/22676591?v=4?s=100" width="100px;" alt="Rahul Shrestha"/><br /><sub><b>Rahul Shrestha</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=rahulbshrestha" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/yogabonito"><img src="https://avatars.githubusercontent.com/u/7026269?v=4?s=100" width="100px;" alt="yogabonito"/><br /><sub><b>yogabonito</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=yogabonito" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/nparent1"><img src="https://avatars.githubusercontent.com/u/52084137?v=4?s=100" width="100px;" alt="Nick Parente"/><br /><sub><b>Nick Parente</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=nparent1" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/Yangliu-SY"><img src="https://avatars.githubusercontent.com/u/144334404?v=4?s=100" width="100px;" alt="Yangliu-SY"/><br /><sub><b>Yangliu-SY</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=Yangliu-SY" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/kmhj13"><img src="https://avatars.githubusercontent.com/u/172297022?v=4?s=100" width="100px;" alt="kmhj13"/><br /><sub><b>kmhj13</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=kmhj13" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/GregVS"><img src="https://avatars.githubusercontent.com/u/83143490?v=4?s=100" width="100px;" alt="Gregory Saldanha"/><br /><sub><b>Gregory Saldanha</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=GregVS" title="Code">💻</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/vivianqin214"><img src="https://avatars.githubusercontent.com/u/56522949?v=4?s=100" width="100px;" alt="vivianqin214"/><br /><sub><b>vivianqin214</b></sub></a><br /><a href="https://github.com/py-why/dowhy/commits?author=vivianqin214" title="Code">💻</a></td>
    </tr>
  </tbody>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->

## Contributing Guide

This project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. This Project welcomes contributions, suggestions, and feedback. All contributions, suggestions, and feedback you submitted are accepted under the [Project's license](./LICENSE). You represent that if you do not own copyright in the code that you have the authority to submit it under the [Project's license](./LICENSE). All feedback, suggestions, or contributions are not confidential.

There are multiple ways to contribute to DoWhy.

You can help us make DoWhy better,
* Adding a Jupyter notebook that describes the use of DoWhy for solving causal
problems

* Helping implement a new method for any of the four steps of causal analysis:
  model, identify, estimate, refute

* Integrating DoWhy's API with external implementations for any of the four steps, so that external libraries can be called seamlessly from the `identify_effect`, `estimate_effect` or `refute_estimate` methods.

* Helping extend the DoWhy API so that we can support new functionality like interpretability of the estimate, counterfactual prediction and more.

* Helping update the documentation for DoWhy

If you would like to contribute, you can raise a pull request. If you have
questions before contributing, you can start by opening an issue on Github.

The Project abides by PyWhy's [code of conduct](https://github.com/py-why/governance/blob/main/CODE-OF-CONDUCT.md) and [trademark policy](https://github.com/py-why/governance/blob/main/TRADEMARKS.md).

---
Part of MVG-0.1-beta.
Made with love by GitHub. Licensed under the [CC-BY 4.0 License](https://creativecommons.org/licenses/by-sa/4.0/).
