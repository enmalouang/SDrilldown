class UnableToConnectError(Exception):
    pass
