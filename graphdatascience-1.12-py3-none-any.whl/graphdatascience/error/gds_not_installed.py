class GdsNotFound(Exception):
    pass
