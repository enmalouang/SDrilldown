__version__ = "1.12"
__min_server_version__ = "2.6.0"  # matches installation.adoc
